/**
 * Trabalho Pr�tico - Classe Problema4Heuristica
 *
 * @author Jonathan Douglas Diego Tavares
 * @matricula 540504
 * @disciplina Algortimos em Grafos
 * @professor Alexei Machado
 */

package Algoritmos;

public class Problema4Heuristica {

}
