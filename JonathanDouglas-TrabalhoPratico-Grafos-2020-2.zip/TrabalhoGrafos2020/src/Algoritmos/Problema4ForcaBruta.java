/**
 * Trabalho Pr�tico - Classe Problema4ForcaBruta
 *
 * @author Jonathan Douglas Diego Tavares
 * @matricula 540504
 * @disciplina Algortimos em Grafos
 * @professor Alexei Machado
 */

package Algoritmos;

public class Problema4ForcaBruta {

}
